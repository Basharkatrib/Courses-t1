<template>
  <span />
</template>

<script>
export default {
  props: ['field', 'viaResource', 'viaResourceId', 'resourceName'],
}
</script>
